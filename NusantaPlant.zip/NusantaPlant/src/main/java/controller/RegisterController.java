package controller;
import javafx.fxml.FXML;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import DAO.UserDAO;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.User;

public class RegisterController
{
    @FXML
    private PasswordField pass;

    @FXML
    private TextField username;

    @FXML
    private Button registerBtn;

    @FXML
    private Text text;

    @FXML
    public void registerUser()
    {
        User user = new User(username.getText(), pass.getText());
        UserDAO.registerUser(user);
        text.setText(user.getUsername() + " berhasil terdaftar!");
    }
}

package model;
import java.util.UUID;

/**
 *
 * @author Admin*/

public class Inventory {
    private UUID idnventory;
    private UUID idUser;
    private UUID dPlant;
    private UUID idItem;
}

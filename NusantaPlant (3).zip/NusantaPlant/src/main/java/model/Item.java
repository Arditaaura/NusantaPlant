
package model;
import java.util.UUID;
import java.util.Date;

/**
 *
 * @author Admin
 */
public class Item {
    private String name;
    private User owner;
    private UUID iud;
    private Date buyDate;
    private Date useDate;
    private int totalItem;
    
    
}
